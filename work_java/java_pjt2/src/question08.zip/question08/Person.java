package question08;

public class Person {

			public String lastName;
			public String firstName;
			
			public int getLength() {
				return lastName.length()+firstName.length();
			}
			
			public String getFirstName() {
				return firstName;
			}
			
			public String getLastName() {
				return lastName;
			}


			

////			Person person1 = new Person(s,r); 
//			System.out.println(person1.fname);
			
			


}
